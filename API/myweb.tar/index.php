<!DOCTYPE HTML>
<html>
	<head>
		<title>THAIVPN</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href="http://fonts.googleapis.com/css?family=Roboto:100,100italic,300,300italic,400,400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!--[if lte IE 8]><script src="css/ie/html5shiv.js"></script><![endif]-->
	
	</head>
<body>
		<div class="card-block">
			<footer>
				<div align="center">
					<form action="" method="POST">
									<div class="input-group">
									<input type="text" class="form-control" name="user" id="user" placeholder="Username" aria-describedby="sizing-addon3">
									</div>
									
									<br>
									<div class="input-group">
									<input class="form-control" type="text" name="pass" id="pass" placeholder="Password" aria-describedby="sizing-addon3">
									</div>
									
									<br>
									<input type="submit" value="สร้างบัญชี" name="submit" class="button alt"/>
					</form>
				</div>
			</footer>
		
		</div>
		
		<header>
<div align="center"><p>
<div align="center">
<?php 
if ($_POST) { 
include('Net/SSH2.php');
$username = $_POST['user'];
$password = $_POST['pass'];
$ssh = new Net_SSH2('xxxxxxxxx:22');
$ssh->login('thaivpnuser', 'thaivpnpass') or die("Login failed");
$ssh->getServerPublicHostKey();
$cmd = "sudo useradd -d /home/$username -p $(perl -e'print crypt(\"$password\", \"cu\")') -e `date -d '7 days' +'%Y-%m-%d'` $username";
$cmdr = $ssh->exec($cmd);
echo "*****ข้อมูลบัญชี******";
echo "<br>";
echo "IP: xxxxxxxxx";
echo "<br>";
echo "Port SSH : 22,443";
echo "<br>";
echo "Proxy: 8080,3128";
echo "<br>";
echo "User: $username";
echo "<br>";
echo "Pass: $password";
echo "<br>";
}
?>
</div></p></div>
</header>
</body>
</html>